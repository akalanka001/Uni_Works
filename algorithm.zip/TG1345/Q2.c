#include<stdio.h>
#include<stdlib.h>
struct node
{
     int num;
	 struct node *nextptr;
}*stnode;

void createNodeList(int n);
void displayList();
int findElement(int num);
void nodeInsertAtBegin(int num);
void nodeInsertAtEnd(int num);
int nodeCount();
void insertNodeAtMiddle(int num, int pos);
void firstNodeDeletion();

int main(){
	 int n; 
	 printf("Input the numbers of nodes : ");
	 scanf("%d",&n);
  	 createNodeList(n);
  	 displayList();
  	 
	 printf("\nInsert a node at the beginning: ");
     nodeInsertatBegin(5);
     displayList();
     
     printf("\nInsert a node at the end: ");
     nodeInsertatEnd(15);
     displayList();

     printf("\nSearch for a node with value 10: %s\n", FindElement(10) ? "Found" : "Not Found");

     printf("\nNumber of nodes: %d\n", NodeCount());

     printf("\nInsert a node at position 2: ");
     insertNodeAtMiddle(25, 2);
     displayList();

     printf("\nDelete the first node: ");
     firstNodeDeletion();
     displayList();

    printf("\nNumber of nodes: %d\n", NodeCount());
  	 
  	 return 0;
}
void createNodeList(int n){
		struct node *fnNode, *tmp;
		int num, i;
		stnode = (struct node *)malloc(sizeof(struct node));
		
		if(stnode == NULL){
			printf("Memory cannot be allocated.");
			exit(0);
		}else{
			printf("Input data for Node 1 : ");
			scanf("%d",&num);
			stnode->num = num;
			stnode->nextptr = NULL;
			tmp = stnode;
			
			for(i=2; i<=n; i++){
				fnNode = (struct node *)malloc(sizeof(struct node));
				
				if(fnNode == NULL){
					printf("Memory cannot be allocated.");
					break;
				}else{
					printf("Input data for node %d : ",i);
					scanf("%d",&num);
					fnNode->num = num;
					fnNode->nextptr = NULL;
					tmp->nextptr = fnNode;
					tmp = tmp->nextptr;
				}	
			}
		}	
}
void displayList(){
	struct node *tmp;
	if(stnode == NULL){
		printf("No data found in the list.");
	}else{
		tmp= stnode;
		while (tmp != NULL){
			printf("Data = %d\n",tmp->num);
			tmp = tmp->nextptr;
		}
	}
			  
 			  
}
int findElement(int num){]
	struct node *tmp = stnode;
	while(tmp != NULL){
		if(tmp->num == num){
			return 1;	
		}
		tmp = tmp->nextptr;
	}
 	return 0;
}
void nodeInsertAtBegin(int num){
	struct node *newNode = (struct node *)malloc(sizeof(struct node));
	if(newNode == NULL){
		printf("Memory can't be allocated.\n");
		exit(0);
	}
	newNode->num = num;
    newNode->nextptr = NULL;

    if (stnode == NULL) {
        stnode = newNode;
    } else {
        struct node *tmp = stnode;
        while (tmp->nextptr != NULL) {
            tmp = tmp->nextptr;
        }
        tmp->nextptr = newNode;
    }
	
}
int nodeCount() {
    struct node *tmp = stnode;
    int count = 0;
    while (tmp != NULL) {
        count++;
        tmp = tmp->nextptr;
    }
    return count;
}
void insertNodeAtMiddle(int num, int pos) {
    int i;
    struct node *newNode, *tmp;

    if (pos == 1) {
        NodeInsertatBegin(num);
    } else {
        newNode = (struct node *)malloc(sizeof(struct node));
        if (newNode == NULL) {
            printf("Memory cannot be allocated.\n");
            return;
        }
        newNode->num = num;
        tmp = stnode;
        for (i = 1; i < pos - 1 && tmp != NULL; i++) {
            tmp = tmp->nextptr;
        }
        if (tmp != NULL) {
            newNode->nextptr = tmp->nextptr;
            tmp->nextptr = newNode;
        } else {
            printf("Invalid position!\n");
            free(newNode);
        }
    }
}
void firstNodeDeletion() {
    struct node *tmp;
    if (stnode != NULL) {
        tmp = stnode;
        stnode = stnode->nextptr;
        free(tmp);
    }
}
