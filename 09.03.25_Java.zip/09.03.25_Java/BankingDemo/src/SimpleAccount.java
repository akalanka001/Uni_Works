public class SimpleAccount {
    private double balance = 0;

    // Atomic withdraw with wait
    public synchronized boolean withdraw(double amount) {
        while (amount > balance) {
            try {
                System.out.println("Not enough money. Waiting...");
                wait();
            } catch (InterruptedException e) {
                return false;
            }
        }
        balance -= amount;
        System.out.printf("Withdrew $%.2f. Balance: $%.2f%n", amount, balance);
        return true;
    }

    // Atomic deposit with notify
    public synchronized void deposit(double amount) {
        balance += amount;
        System.out.printf("Deposited $%.2f. Balance: $%.2f%n", amount, balance);
        notifyAll();
    }
}
