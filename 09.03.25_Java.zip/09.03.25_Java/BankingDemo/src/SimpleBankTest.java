public class SimpleBankTest {
    public static void main(String[] args) {
        SimpleAccount acct = new SimpleAccount();


        Thread withdrawer = new Thread(new Runnable() {
            @Override
            public void run() {
                acct.withdraw(100);
            }
        });


        Thread depositor = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(500);  // Wait half second
                } catch (InterruptedException e) {
                    return;
                }
                acct.deposit(150);
            }
        });

        withdrawer.start();
        depositor.start();
    }
}
