public class Pen {
    public synchronized void needPaper(Paper paper) {
        System.out.println(Thread.currentThread().getName() + ": I have a Pen, I needPaper");
        paper.finishPen();
    }

    public synchronized void finishPaper(){
        System.out.println(Thread.currentThread().getName() + ": Im Finished writing to Paper");
    }
}
