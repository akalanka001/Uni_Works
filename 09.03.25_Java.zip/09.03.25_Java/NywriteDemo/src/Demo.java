public class Demo {
    public static void main(String[] args) {
        Paper paper = new Paper();
        Pen pen = new Pen();

        Thread kamal = new Thread("Kamal") {
            public void run() {
                synchronized (pen) {
                    paper.needPen(pen);
                }
            }
        };

        Thread nimal = new Thread("Nimal") {
            public void run() {
                synchronized (paper){
                    pen.needPaper(paper);
                }
            }
        };

        kamal.start();
        nimal.start();
    }
}
