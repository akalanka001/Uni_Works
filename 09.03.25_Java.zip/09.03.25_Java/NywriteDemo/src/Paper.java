public class Paper {
    public synchronized void needPen(Pen pen) {
        System.out.println(Thread.currentThread().getName() + ": I have a Paper, I needPen");
        pen.finishPaper();
    }

    public synchronized void finishPen(){
        System.out.println(Thread.currentThread().getName() + ": I finished writing to Paper");
    }
}
