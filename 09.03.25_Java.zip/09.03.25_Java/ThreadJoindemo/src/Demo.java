public class Demo {
    public static void main(String[] args) throws InterruptedException {

        ThreadJoin threadJoin = new ThreadJoin();

        Thread t1 = new Thread(threadJoin, "Thread1");
        Thread t2 = new Thread(threadJoin, "Thread2");

        t2.start();
        t2.join();
        t1.start();

    }
}
