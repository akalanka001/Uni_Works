public class ThreadJoin extends Thread {
    @Override
    public void run() {

        System.out.println("Thread Started " + Thread.currentThread().getName());
        try {
            Thread.sleep(4000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        System.out.println("Thread Finished " + Thread.currentThread().getName());
    }
}
