public class Account {
    private double balance;

    public synchronized void deposit(double amount) {
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        this.balance += amount;
        notifyAll();
        System.out.println("Deposited " + amount + " to the account.");
    }

    public synchronized void withdraw(double amount) {
        System.out.println("Trying to withdraw " + amount + " from the account.");
        if(amount > this.balance) {
            System.out.println("Insufficient funds, Waiting ...");
            try {
                wait();
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }else{
            this.balance -= amount;
            System.out.println("Withdrawn " + amount + " from the account.");
        }

    }

}
