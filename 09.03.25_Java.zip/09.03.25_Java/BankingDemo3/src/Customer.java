public class Customer {

    public static void main(String[] args) {
        Account account = new Account();

        Thread withdrawThread = new Thread(){
            public void run(){
                account.withdraw(100);
            }
        };

        Thread depositThread = new Thread(){
            public void run(){
                try {
                    sleep(1000);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
                account.deposit(200);
            }
        };

        withdrawThread.start();
        depositThread.start();


    }

}
