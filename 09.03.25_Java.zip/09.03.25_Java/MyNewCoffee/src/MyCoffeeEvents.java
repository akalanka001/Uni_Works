public class MyCoffeeEvents implements Runnable {

    private String msg;

    public MyCoffeeEvents(String msg) {
        this.msg = msg;
    }

    @Override
    public void run() {
        System.out.println(msg);
    }
}
