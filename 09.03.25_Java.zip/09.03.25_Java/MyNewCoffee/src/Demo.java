import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class Demo {
    public static void main(String[] args) {
        ScheduledThreadPoolExecutor executor = new ScheduledThreadPoolExecutor(1);
        MyCoffeeEvents coffee = new MyCoffeeEvents("Adding Coffee...");
        MyCoffeeEvents sugar = new MyCoffeeEvents("Adding Sugar...");
        MyCoffeeEvents water = new MyCoffeeEvents("Adding Water...");
        MyCoffeeEvents serve = new MyCoffeeEvents("Serving Coffee...");

        executor.schedule(coffee,4, TimeUnit.SECONDS);
        executor.schedule(sugar,7, TimeUnit.SECONDS);
        executor.schedule(water,11, TimeUnit.SECONDS);
        executor.schedule(serve,20, TimeUnit.SECONDS);
        executor.shutdown();
    }
}
