public class Main {
    public static void main(String[] args) {
        MyTimer mt1 = new MyTimer();
//        MyTimer mt2 = new MyTimer();

        Thread t1 = new Thread(mt1);
        Thread t2 = new Thread(mt1);

        t1.setName("My Timer 1");
        t2.setName("My Timer 2");

        t1.start();
        t2.start();
    }
}
