import static java.lang.Thread.sleep;

public class MyTimer implements Runnable {

    @Override
    public void run() {
        this.printReNumbers();
        this.printNumbers();

    }
    private synchronized void printNumbers(){
        for (int i = 1; i <= 10; i++) {

            System.out.println(Thread.currentThread().getName() + " : " + i);
            System.out.println();
            try {
                sleep(1000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }
    private void printReNumbers(){
        for (int i = 10; i > 0; i--) {

            System.out.println(Thread.currentThread().getName() + " de: " + i);
            System.out.println();
            try {
                sleep(1000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }
}
