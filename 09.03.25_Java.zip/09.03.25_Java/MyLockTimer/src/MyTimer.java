import java.util.concurrent.locks.ReentrantLock;

public class MyTimer extends Thread {

    ReentrantLock lock = new ReentrantLock();

    @Override
    public void run() {
        timer();
    }
    private void timer() {
        lock.lock();
        for(int i=10; i>0; i--) {
            System.out.println(i);
            try {
                sleep(1000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
        lock.unlock();
    }
}
