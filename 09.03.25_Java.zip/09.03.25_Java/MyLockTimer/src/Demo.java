import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

public class Demo {
    public static void main(String[] args) {

        ScheduledExecutorService exec = Executors.newScheduledThreadPool(2);
        MyTimer timer = new MyTimer();

        exec.execute(timer);
        exec.execute(timer);
        exec.shutdown();

    }
}
