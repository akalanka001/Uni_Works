public class Main {
    public static void main(String[] args) {
        Thread t1 = new Thread(() -> {
            for (int i = 0; i < 5; i++) {
                System.out.println("t1: " + i);
                Thread.yield();   // "I’ll pause and let someone else run"
            }
        });

        Thread t2 = new Thread(() -> {
            for (int i = 0; i < 5; i++) {
                System.out.println("t2: " + i);
                Thread.yield();
            }
        });

        t1.start();
        t2.start();

    }
}
