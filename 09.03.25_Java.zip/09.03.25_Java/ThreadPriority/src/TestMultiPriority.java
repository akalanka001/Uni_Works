public class TestMultiPriority extends Thread {
    public void run() {
        Thread.yield();
        System.out.println("The thread name is " + Thread.currentThread().getName());
        System.out.println("The thread priority is " + Thread.currentThread().getPriority());
        try {
            sleep(1000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

}
