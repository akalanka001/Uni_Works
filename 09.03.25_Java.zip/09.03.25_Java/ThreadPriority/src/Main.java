public class Main {
    public static void main(String[] args) throws InterruptedException {
        TestMultiPriority t1 = new TestMultiPriority();
        TestMultiPriority t2 = new TestMultiPriority();

        t1.setPriority(Thread.MAX_PRIORITY);
        t2.setPriority(Thread.MAX_PRIORITY);

        t1.start();
        t2.start();
    }
}
