<html>
	<body>
		<form name='login' action='' method='post'>
			<table>
				<tr>
					<td>Username:</td>
					<td><input type='text' name='username' ></td>
				</tr>
				<tr>
					<td>Password:</td>
					<td><input type='text' name='password' ></td>
				</tr>
				<tr>
					<td><input type='submit' value='Submit' ></td>
					<td><input type='reset' value='Reset' ></td>
				</tr>
			</table>
		</form>
		<?php
			require 'Ex01.php';
			if($_SERVER['REQUEST_METHOD'] == 'POST'){
				$username = $_POST['username'];
				$plainPassword = $_POST['password'];
				$hashedPassword = md5($plainPassword);
				
				$sql = "SELECT userName from user where username = ?;";
				
				$stmt = mysqli_prepare($link,$sql);
				
				mysqli_stmt_execute($stmt);
				mysqli_stmt_store_result($stmt);

				if (mysqli_stmt_num_rows($stmt) == 0) {
					echo "Please enter a valid username";
				} else {
					echo "Username correct";
				}else {
					echo "Failed to prepare the statement";
				}
			mysqli_stmt_close($stmt);
			mysqli_close($link);
			}
			
			
		?>
	</body>
</html>