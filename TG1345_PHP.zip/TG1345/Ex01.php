<?php
	$link = mysqli_connect('localhost','root','');
	if(!$link){
		die('Cant connect : '.mysqli_error($link));
	}
	echo "Connected Successfully<br>";
	
	
	
	//create BICT database;
	$sql = "CREATE DATABASE BICT";
	mysqli_query($link,$sql);
	
	//select DATABASE
	$db_selected = mysqli_select_db($link,'BICT');
	if (!$db_selected){
		die ("Can't use library : ". mysqli_error($link));
	}
	//create  user table
	$sql = "CREATE TABLE IF NOT EXISTS user(
				userId int AUTO_INCREMENT primary key,
				userName varchar(20),
				password varchar(60),
				email varchar(20),
				role varchar(20))";
	if(!mysqli_query($link,$sql)){
		die ("Can't create : ". mysqli_error($link));
	}
	echo "Tables are created successfully<br>";
				
				
	//create  subject table	
	$sql = "CREATE TABLE IF NOT EXISTS subject(
				subjectCode char(7) primary key,
				subjectName varchar(20),
				credits int
			)";
			
	if(!mysqli_query($link,$sql)){
		die ("Can't create : ". mysqli_error($link));
	}
	echo "Tables are created successfully<br>";
	
			
	//create student table		
	$sql = "CREATE TABLE IF NOT EXISTS student(
				studentId char(6) primary key,
				studentName varchar(20),
				age int,
				subjects int
			);";
	
	if(!mysqli_query($link,$sql)){
		die ("Can't create : ". mysqli_error($link));
	}
	echo "Tables are created successfully<br>";
	
	//insert data into user
	$sql = "INSERT IGNORE INTO user VALUES
			(1,'admin',md5('admin123'),'admin@gmail.com','administrator')
			ON DUPLICATE KEY UPDATE
			userName = VALUES(userName),
			password = VALUES(password),
			email = VALUES(email),
			role = VALUES(role);";
	
	if(!mysqli_query($link,$sql)){
		die ("Can't insert : ". mysqli_error($link));
	}
	echo "Tables are created successfully<br>";
	
	
	mysqli_close($link);
?>