<?php
	if($_SERVER['REQUEST_METHOD'] == 'POST'){
		
		if(isset($_POST['submit'])){
			//get Name
			$name = htmlspecialchars($_POST['name']);
			//get province
			$province = htmlspecialchars($_POST['province']);
			
			//get address
			$address = htmlspecialchars($_POST['address']);
			
			//get Title
			$selected_radio = htmlspecialchars($_POST['title']);
			if($selected_radio == 'mr'){
				$title = "Mr.";
			}
			else if($selected_radio == 'mrs'){
				$title = "Mrs.";
			}
			else if($selected_radio == 'miss'){
				$title = "Miss.";
			}
			
			//events
			$events = isset($_POST['event'])?$_POST['event']:[];
			$eventlist = implode('<li>',$events);
			//output
			if(!empty($name) && !empty($title) && !empty($province) && !empty($events)){
				echo $title.$name. "(".$address.$province.")<br>";
				echo "<p>We are happy to welcome you to the following events :</p>";
				echo "<ul><li>".$eventlist."</li></ul>";
			}else{
				echo "<h2>Sorry, Your form is not complete</h2>";
			}
			
		}
		
		
		
		
	}
?>