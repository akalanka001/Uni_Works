<?php
	/*if($_SERVER['REQUEST_METHOD'] == 'GET'){
		$name = $_GET['name'];
		$age = $_GET['age'];
		
		echo "Welcome ".$name.". Your age is : ".$age;
	}*/
	$name = $_GET['name'];
	$age = $_GET['age'];
	
	echo "Welcome ".htmlspecialchars($name).". Your age is : ".htmlspecialchars($age);
?>