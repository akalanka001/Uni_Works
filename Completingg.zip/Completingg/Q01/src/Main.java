//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        ConfigurationManager cm1 = ConfigurationManager.getInstance();
        ConfigurationManager cm2 = ConfigurationManager.getInstance();

        cm1.getConfigValue("db_url");

        if(cm1 == cm2){
            System.out.println("Both objects are using  Single instance");
        }

    }
}