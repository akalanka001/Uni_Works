public class ConfigurationManager {

    private String DB_URL = "jdbc:mysql://localhost:3306/appdb";
    private int TIMEOUT = 30;
    private String USER = "root";

    private static ConfigurationManager instance;

    private ConfigurationManager() {

    }
    public String getConfigValue(String key){
        if(key.equalsIgnoreCase("db_url")){
            return DB_URL;
        }
        if(key.equalsIgnoreCase("user")){
            return USER;
        }
        if(key.equalsIgnoreCase("timeout")){
            return String.valueOf(TIMEOUT);
        }
        return null;
    }

    public static ConfigurationManager getInstance() {
        if (instance == null) {
            instance = new ConfigurationManager();
        }
        return null;
    }
}
