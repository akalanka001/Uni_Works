public class ShapeFactory {



    public Shape getShape(String shapeName) {
        if (shapeName.equals("circle")) {
            return new Circle();
        }
        else if (shapeName.equals("square")) {
            return new Square();
        }
        else if (shapeName.equals("rectangle")) {
            return new Rectangle();
        }
        return null;
    }
}
