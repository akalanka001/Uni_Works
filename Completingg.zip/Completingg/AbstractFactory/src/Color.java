public interface Color {
    void fill();
}
