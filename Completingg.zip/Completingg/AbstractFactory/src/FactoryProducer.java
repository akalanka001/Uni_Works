public class FactoryProducer {
    public AbstractFactory getFactory(String name) {
        if(name.equalsIgnoreCase("c")) {
            return new ColorFactory();
        }else if(name.equalsIgnoreCase("s")) {
            return new ShapeFactory();
        }
        return null;
    }
}
