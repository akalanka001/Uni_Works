public class MyDbConnection {

    private static final MyDbConnection myDb = new MyDbConnection();

    private MyDbConnection() {}

    public static MyDbConnection getInstance() {

        return myDb;
    }

}
