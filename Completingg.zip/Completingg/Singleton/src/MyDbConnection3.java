public class MyDbConnection3 {
    private static MyDbConnection3 myDb;
    private MyDbConnection3() {

    }
    static {
        try{
            if(myDb == null) {
                myDb = new MyDbConnection3();
            }
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    public static MyDbConnection3 getInstance() {
        return myDb;
    }
}
