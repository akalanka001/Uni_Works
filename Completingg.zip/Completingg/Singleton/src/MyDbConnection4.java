public class MyDbConnection4 {
    private static MyDbConnection4 myDb;
    private MyDbConnection4() {

    }


    public static synchronized MyDbConnection4 getInstance() {
        if(myDb == null) {
            myDb = new MyDbConnection4();
        }
        return myDb;
    }

}
