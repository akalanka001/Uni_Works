//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
//        MyDbConnection myDb1 = MyDbConnection.getInstance();
//        MyDbConnection myDb2 = MyDbConnection.getInstance();
//
//        System.out.println(myDb1.equals(myDb2));

//        MyDbConnection myDb3 = MyDbConnection.getInstance();
        BillPugh bp1 = BillPugh.getInstance();
        BillPugh bp2 = BillPugh.getInstance();

        System.out.println(bp1 == bp2);


    }
}