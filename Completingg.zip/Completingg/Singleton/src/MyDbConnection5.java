public class MyDbConnection5 {
    private static MyDbConnection5 myDb;
    private MyDbConnection5() {

    }


    public static MyDbConnection5 getInstance() {
        synchronized (MyDbConnection5.class) {
            if (myDb == null) {
                myDb = new MyDbConnection5();
            }
        }
        return myDb;
    }
}
