public class MyDbConnection2 {
    private static MyDbConnection2 myDb;
    private MyDbConnection2() {

    }
    public static MyDbConnection2 getInstance() {
        if (myDb == null) {
            myDb = new MyDbConnection2();
        }
        return myDb;
    }
}
