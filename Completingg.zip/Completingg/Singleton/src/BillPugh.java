public class BillPugh {

    // Private constructor — prevent direct instantiation
    private BillPugh() {
        System.out.println("Singleton instance created!");
    }

    // Static inner class — loaded only when getInstance() is called
    private static class Holder {
        private static final BillPugh INSTANCE = new BillPugh();
    }

    // Public accessor
    public static BillPugh getInstance() {
        return Holder.INSTANCE;
    }
}