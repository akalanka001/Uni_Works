<html>
<body>
<?php
	$i;
	$j;
	$n = 7;
	echo " _* * * *<br>";
	echo "* <br>";
	echo "* <br>";
	echo "__* * * <br>";
	echo "_______*<br>";
	echo "_______*<br>";
	echo "_* * * *<br>";
	
	
?>
</body>
</html>