<html>
<body>
<?php
	$fruits = array("Mango","Orange","Apple","Papaya","Banana");
	$i;
	$arrlength = count($fruits);
	for($i=0;$i<$arrlength;$i++){
		print($fruits[$i]."<br>");
	}
	echo "<br><br>";
	sort($fruits);
	for($i=0;$i<$arrlength;$i++){
		print($fruits[$i]."<br>");
	}
		
?>
</body>
</html>