<html>
<body>
<?php
	$i;
	$j;
	$n = 5;
	for($i=1; $i<=$n; $i++){
		for($j=1; $j<=$i; $j++){
			print("* ");
		}
		print ("<br>");
	}
?>
</body>
</html>