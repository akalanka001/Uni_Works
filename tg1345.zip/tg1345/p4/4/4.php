<html>
<body>
<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $n1 = isset($_POST['n1']) ? (float)$_POST['n1'] : 0;
    $n2 = isset($_POST['n2']) ? (float)$_POST['n2'] : 0;
    $operation = isset($_POST['operation']) ? $_POST['operation'] : '';

    $result = '';

    
    switch ($operation) {
        case 'addition':
            $result = $n1 + $n2;
            break;
        case 'subtract':
            $result = $n1 - $n2;
            break;
        case 'divide':
            if ($n2 != 0) {
                $result = $n1 / $n2;
            } else {
                $result = 'Cannot divide by zero';
            }
            break;
        case 'multiplication':
            $result = $n1 * $n2;
            break;
        default:
            $result = 'Invalid operation';
    }


    echo "Result: " . $result;
}
?>


</body>
</html>