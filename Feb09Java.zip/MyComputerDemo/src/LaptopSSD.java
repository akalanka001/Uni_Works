public class LaptopSSD extends LaptopDecorator{

    private Laptop bLap;

    public LaptopSSD(Laptop bLap) {
        this.bLap = bLap;
    }

    @Override
    public String display() {
        return bLap.display() + " With SSD";
    }
}
