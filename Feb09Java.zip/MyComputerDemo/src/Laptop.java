public class Laptop {
    public Laptop() {
    }
    public String display() {
        return "Basic Laptop";
    }
}
