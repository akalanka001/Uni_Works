public abstract class LaptopDecorator extends Laptop{
    public abstract String display();
}
