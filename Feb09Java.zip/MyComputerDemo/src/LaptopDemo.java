public class LaptopDemo {
    public static void main(String[] args) {
        Laptop bLap = new Laptop();
        LaptopSSD lapSSD = new LaptopSSD(bLap);
        LaptopDVD lapDVD = new LaptopDVD(bLap);
        Laptop myLapSsdDvd = new LaptopSSD(lapDVD);


        System.out.println(bLap.display());    // Basic Laptop
        System.out.println(lapSSD.display());  // Laptop with SSD
        System.out.println(lapDVD.display());  // Laptop with DVD
        System.out.println(myLapSsdDvd.display()); // Laptop with SSD + DVD
    }
}
