public class LaptopDVD extends LaptopDecorator{
    Laptop bLap;

    public LaptopDVD(Laptop bLap) {
        this.bLap = bLap;
    }


    @Override
    public String display() {
        return bLap.display() + " With Laptop DVD";
    }
}
