import java.util.Scanner;

public class Demo {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        MyDifficultRegistration registration = new MyDifficultRegistration();

//        System.out.print("Enter Your regNo first char : ");
//        registration.setFirstCharacter(sc.next().charAt(0));
//
//        System.out.println("Enter your regNo second char : ");
//        registration.setSecondCharacter(sc.next().charAt(0));
//
//        System.out.println("Enter your regNo third char : ");
//        registration.setThirdCharacter(sc.next().charAt(0));
//
//        System.out.println("Enter your regNo fourth char : ");
//        registration.setFourthCharacter(sc.next().charAt(0));
//
//        System.out.println("Enter your regNo fifth char : ");
//        registration.setFifthCharacter(sc.next().charAt(0));
//
//        System.out.println("Enter your regNo sixth char : ");
//        registration.setSixthCharacter(sc.next().charAt(0));
//
        System.out.println("Enter Your Registration Number : ");
        String regNum = sc.next();
        System.out.println("Your Registration Number is : " + registration.getRegNo());


    }
}
