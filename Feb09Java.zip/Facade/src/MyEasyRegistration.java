public class MyEasyRegistration {
    MyDifficultRegistration dr = new MyDifficultRegistration();
    String regNo;

    public MyEasyRegistration(String regNum) {
        this.regNo = regNum;
    }

    public void setRegNo(String regNo) {
        dr.setFirstCharacter(regNo.charAt(0));
        dr.setSecondCharacter(regNo.charAt(1));
        dr.setThirdCharacter(regNo.charAt(2));
        dr.setFourthCharacter(regNo.charAt(3));
        dr.setFifthCharacter(regNo.charAt(4));
        dr.setSixthCharacter(regNo.charAt(5));
    }
}
