public abstract class BeverageMaker {
    public final void makeBeverage() {
        boilWater();
        brew();
        pourInCup();
        addCondiments();
    }
    private void boilWater(){
        System.out.println("Boiling Water");
    }
    private void pourInCup(){
        System.out.println("Pouring Cup");
    }
    protected abstract void brew();
    protected abstract void addCondiments();
}
