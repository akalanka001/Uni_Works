public class Demo {
    public static void main(String[] args) {
        BeverageMaker tea = new TeaMaker();
        tea.makeBeverage();
        System.out.println();

        BeverageMaker coffee = new CoffeeMaker();
        coffee.makeBeverage();

    }
}
