public class CoffeeMaker extends BeverageMaker{
    @Override
    protected void brew() {
        System.out.println("Brewing Coffee");
    }

    @Override
    protected void addCondiments() {
        System.out.println("Adding Condiments to coffee");
    }
}
