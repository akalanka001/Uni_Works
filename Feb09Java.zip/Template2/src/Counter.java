import static java.lang.Thread.sleep;

public class Counter {
    public static void main(String[] args) throws InterruptedException {
        for(int i = 10; i >= 1; i--) {
            System.out.println(i);
            sleep(1000);
        }

    }
}
