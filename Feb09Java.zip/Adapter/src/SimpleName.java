public class SimpleName implements SimpleNameInterface{

    private String name;

    @Override
    public void setSimpleName(String simpleName) {
        this.name = simpleName;
    }

    @Override
    public String getSimpleName() {
        return this.name;
    }

}
