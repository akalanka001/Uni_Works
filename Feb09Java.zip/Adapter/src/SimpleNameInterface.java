public interface SimpleNameInterface {
    void setSimpleName(String simpleName);
    String getSimpleName();
}
