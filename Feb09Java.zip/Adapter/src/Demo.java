import java.util.Scanner;

public class Demo {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        SimpleName simpleName = new SimpleName();
        System.out.print("Enter your name (first last): ");
        String nameIn = sc.nextLine();
        simpleName.setSimpleName(nameIn);

        // Use adapter to view as ComplexNameInterface
        ComplexNameInterface complexName = new Adapter(simpleName);

        System.out.println("First name: " + complexName.getFirstName());
        System.out.println("Last name: " + complexName.getLastName());

    }
}
