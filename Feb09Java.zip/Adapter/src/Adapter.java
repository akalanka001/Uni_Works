public class Adapter implements ComplexNameInterface{
    private String firstName;
    private String lastName;

    private SimpleName simpleName;

    public Adapter(SimpleName simpleName) {
        this.simpleName = simpleName;
        firstName = simpleName.getSimpleName().split(" ")[0];
        lastName = simpleName.getSimpleName().split(" ")[1];
    }


    @Override
    public void setFirstName(String firstName) {
        this.firstName = firstName;
        updateSimpleName();
    }

    @Override
    public void setLastName(String lastName) {
        this.lastName = lastName;
        updateSimpleName();
    }

    private void updateSimpleName() {
        // Keep SimpleName in sync
        simpleName.setSimpleName(firstName + " " + lastName);
    }
    public String getFirstName() {
        return firstName;
    }
    public String getLastName() {
        return lastName;
    }

}
