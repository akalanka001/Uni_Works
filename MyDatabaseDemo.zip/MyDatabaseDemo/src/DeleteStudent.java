import java.sql.Statement;

public class DeleteStudent {
    public static void main(String[] args) throws Exception {
        try {
            String sql = "delete from basicData where stu_id = 'TG/004'";
            MyDbConnector dbConnector = new MyDbConnector();

            Statement stmt = dbConnector.getConnection().createStatement();
            if (stmt.executeUpdate(sql) == 1) {
                System.out.println("Student deleted successfully");
            };
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
