import java.sql.SQLException;
import java.sql.Statement;

public class InsertStudent {
    public static void main(String[] args) throws SQLException {
        MyDbConnector dbConnector = null;
        try {
            String sql = "insert into basicData values('TG/010','illeperuma','kataburana')";
            dbConnector = new MyDbConnector();

            Statement stmt = dbConnector.getConnection().createStatement();
            if(stmt.executeUpdate(sql) == 1)
                System.out.println("Insert Successful");

        } catch (Exception e) {
            throw new RuntimeException(e);
        }finally {
            dbConnector.getConnection().close();
        }

    }
}
