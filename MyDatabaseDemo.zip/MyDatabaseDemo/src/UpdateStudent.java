import java.sql.SQLException;
import java.sql.Statement;

public class UpdateStudent {
    public static void main(String[] args) throws Exception {
        try {
            String sql = "update basicData set stu_name = 'danuja putha' where stu_id = 'TG/003'";
            MyDbConnector dbConnector = new MyDbConnector();

            Statement stmt = dbConnector.getConnection().createStatement();
            if (stmt.executeUpdate(sql) == 1) {
                System.out.println("Update successful");
            };
        } catch (Exception e) {
            throw new RuntimeException(e);
        }


    }
}
