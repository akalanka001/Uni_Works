import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DisplayStudent {
    public static void main(String[] args) throws Exception {
        String sql = "SELECT * FROM basicData";
        MyDbConnector dbConnector = new MyDbConnector();

        try {
            Statement stmt = dbConnector.getConnection().createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                System.out.println(rs.getString(1) + " " + rs.getString(2) + " " + rs.getString(3));
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        dbConnector.getConnection().close(); // Close resources after use
    }
}