package com.ictec.server;

import com.ictec.Department;
import com.ictec.DepartmentStudent;
import com.ictec.Student;

import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class FOTServer {
    public static void main(String[] args) {
        try {
            Registry registry = LocateRegistry.createRegistry(45321);
            Department depStudent = new DepartmentStudent();
            registry.rebind("Student",depStudent);
            System.out.println("Server is ready");
        } catch (RemoteException e) {
            System.out.println(e.getCause());
        }
    }

}
