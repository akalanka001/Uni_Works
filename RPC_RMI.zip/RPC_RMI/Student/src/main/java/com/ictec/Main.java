package com.ictec;

import com.ictec.db.DBConnection;

public class Main {
    public static void main(String[] args) {
        DBConnection db = new DBConnection();
        db.getConnection();
    }
}
