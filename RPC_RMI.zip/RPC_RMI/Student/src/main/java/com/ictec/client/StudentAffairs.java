package com.ictec.client;

import com.ictec.Department;
import com.ictec.Student;

import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.ArrayList;

public class StudentAffairs {
    public static void main(String[] args) {


        try {
            Registry registry = LocateRegistry.getRegistry("localhost", 45321);
            Department dep = (Department) registry.lookup("Student");

            ArrayList<Student> list = dep.getStudents();
            for(Student s : list){
                System.out.println(s);
            }
        } catch (RemoteException e) {
            System.out.println(e.getMessage());
        } catch (NotBoundException e) {
            System.out.println(e.getMessage());
        }


    }
}
