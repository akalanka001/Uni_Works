package com.ictec;

import com.ictec.db.DBConnection;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class DepartmentStudent extends UnicastRemoteObject implements Department {


    public DepartmentStudent() throws RemoteException {
        super();
    }

    @Override
    public ArrayList<Student> getStudents() throws RemoteException {

        ArrayList<Student> students = new ArrayList<>();

        String query = "SELECT * FROM basicdata";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {

                String id = rs.getString("stu_id");
                String name = rs.getString("stu_name");
                String address = rs.getString("stu_address");

                Student student = new Student(id, name, address);
                students.add(student);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return students;
    }
}
