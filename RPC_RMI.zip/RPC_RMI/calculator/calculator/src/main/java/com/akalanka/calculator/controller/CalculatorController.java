package com.akalanka.calculator.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class CalculatorController {

    CalculatorService calculatorService;

    public CalculatorController(CalculatorService calculatorService) {
        this.calculatorService = calculatorService;
    }

    @GetMapping("/")
    public String showCalculator(Model model) {
        return "calculator";
    }

    @PostMapping("/add")
    public String add(@RequestParam double num1, @RequestParam double num2, Model model) {
        double result = calculatorService.add(num1, num2);
        model.addAttribute("num1", num1);
        model.addAttribute("num2", num2);
        model.addAttribute("result", result);
        return "calculator";
    }

    @PostMapping("/sub")
    public String subtract(@RequestParam double num1, @RequestParam double num2, Model model) {
        double result = calculatorService.subtract(num1, num2);
        model.addAttribute("num1", num1);
        model.addAttribute("num2", num2);
        model.addAttribute("result", result);
        return "calculator";
    }

    @PostMapping("/div")
    public String divide(@RequestParam double num1, @RequestParam double num2, Model model) {
        try {
            double result = calculatorService.divide(num1, num2);
            model.addAttribute("result", result);
        } catch (ArithmeticException e) {
            model.addAttribute("error",e.getMessage());
        }
        model.addAttribute("num1", num1);
        model.addAttribute("num2", num2);

        return "calculator";
    }

    @PostMapping("/mul")
    public String multiply(@RequestParam double num1, @RequestParam double num2, Model model) {
        double result = calculatorService.multiply(num1, num2);
        model.addAttribute("result", result);
        model.addAttribute("num1", num1);
        model.addAttribute("num2", num2);
        return "calculator";
    }


}