package com.ictec.server;

import com.ictec.calc.Calculator;
import com.ictec.calc.MyCalculator;

import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class MyServer {
    public static void main(String[] args) {
        try {
            //create Registry
            Registry registry = LocateRegistry.createRegistry(54321);

            //binding registry
            Calculator myCal = new MyCalculator();
            registry.rebind("Calculator", myCal);

            System.out.println("My Calculator Server is running");

        } catch (RemoteException e) {
            System.out.println(e.getMessage());
        }
    }
}
