package com.ictec.client;

import com.ictec.calc.Calculator;

import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class MyClient {
    public static void main(String[] args) {
        try {
            Registry registry = LocateRegistry.getRegistry("localhost",54321);

            Calculator cal =  (Calculator) registry.lookup("Calculator");


            double add = cal.add(1,2);
            System.out.println(add);

            double sub = cal.sub(2,1);
            System.out.println(sub);

            double mul = cal.mul(2,1);
            System.out.println(mul);

            try {
                double div = cal.div(2,0);
                System.out.println(div);
            } catch (ArithmeticException e) {
                System.out.println("Cannot divide by zero");
            }


        } catch (RemoteException | NotBoundException e) {
            System.out.println(e.getMessage());
        }
    }
}
