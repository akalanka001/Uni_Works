public class Code
{
	public class void main(String[] args){
		Cylinder c1 = new Cylinder();
		//Cylinder c2 = new Cylinder(10,0);
		//Cylinder c3 = new Cylinder(7.0,10.0);

		
	}
}