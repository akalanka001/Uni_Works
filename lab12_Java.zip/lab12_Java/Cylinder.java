public class Cylinder extends Circle
{
	private double height = 1.0;
	
	Cylinder(){
		getVolume();
	}

	Cylinder(double height){
		getHeight();
	}
	
	Cylinder(double radius, double height){
		
	}

	public double getHeight(){
		
	}
	
	public void setHeight(double height){

	}
		
	public double getVolume(){
		 
	}
	
}