public class Circle
{
	private double radius = 1.0;
	Circle(){
		getArea();
	}
	Circle(double radius){
		getRadius();
	}
	public double getRadius(){
		
	}
	public void setRadius(double radius){
		
	}	
	double getArea(){
		double area = Math.PI * MAth.pow(radius,2);
		System.out.println("Area of Circle : " + area);
	}
}