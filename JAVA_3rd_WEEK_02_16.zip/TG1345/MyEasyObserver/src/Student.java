import java.util.Observable;
import java.util.Observer;

public class Student implements Observer {

    private String name;

    public Student(String name) {
        this.name = name;
    }

    @Override
    public void update(Observable o, Object arg) {
        if(o instanceof TecLMS){
            System.out.println("I'm Student : " + this.name + " I got the message : " + ((TecLMS) o).msg);
        }
    }
}
