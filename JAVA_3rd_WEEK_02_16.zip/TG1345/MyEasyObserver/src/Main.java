public class Main {
    public static void main(String[] args) {
        TecLMS t = new TecLMS();

        Student nimal = new Student("Nimal");
        Student alan = new Student("Alan");
        Student sam = new Student("Sam");

        t.addObserver(nimal);
        t.addObserver(alan);
        t.deleteObserver(alan);
        t.deleteObservers();
        t.addObserver(sam);

        t.sendMessage();

    }
}