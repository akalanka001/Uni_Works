import java.util.Observable;
import java.util.Scanner;

public class TecLMS extends Observable {

    public String msg;
    Scanner sc = new Scanner(System.in);

    public void sendMessage() {
        System.out.println("Please enter your message: ");
        msg = sc.nextLine();
        setChanged();
        notifyObservers();
    }
}
