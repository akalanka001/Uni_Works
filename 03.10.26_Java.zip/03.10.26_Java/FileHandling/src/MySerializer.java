import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class MySerializer {
    public static void main(String[] args) {
        Student stu = new Student(1,"Kamal");
        Student.setAge(20);
        stu.setPassword("KamalPassword");

        try {
            FileOutputStream fos = new FileOutputStream("stu.ser");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(stu);
            oos.flush();
            oos.close();
            fos.close();

        } catch (FileNotFoundException e) {
            System.out.println(e.getMessage());
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
}
