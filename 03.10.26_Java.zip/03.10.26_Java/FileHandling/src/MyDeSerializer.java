import java.io.*;

public class MyDeSerializer {
    public static void main(String[] args) {
        String filePath = "stu.ser";

        try(FileInputStream fis = new FileInputStream(filePath);
            ObjectInputStream ois = new ObjectInputStream(fis)){

            Student stu = (Student) ois.readObject();
            System.out.println("Student Id: " + stu.getId());
            System.out.println("Name: " + stu.getName());
            System.out.println("Age: " + Student.getAge());
            System.out.println("Password: " + stu.getPassword());

        } catch (FileNotFoundException e) {
            System.out.println("Serialized file not found: " + filePath);
        } catch (IOException e) {
            System.out.println("I/O Error: " + e.getMessage());
        } catch (ClassNotFoundException e) {
            System.out.println("Student class not found or incompatible: " + e.getMessage());
        }
    }
}
