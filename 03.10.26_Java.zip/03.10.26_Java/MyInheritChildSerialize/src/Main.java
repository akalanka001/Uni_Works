public class Main {
    public static void main(String[] args) {

        Animal dog = new Animal(100.0);

        AnimalSerializer.animalSerializer(dog);
        AnimalSerializer.animalDeserializer(dog);

    }
}