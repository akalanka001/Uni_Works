import java.io.Serializable;

public class  Dog extends Animal implements Serializable {

    private String color;

    public Dog(double weight) {
        super(weight);
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    @Override
    public String toString() {
        return "Dog{" +
                "color='" + color + '\'' +
                '}';
    }
}
