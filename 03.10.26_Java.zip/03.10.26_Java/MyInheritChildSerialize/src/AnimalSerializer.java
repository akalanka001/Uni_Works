import java.io.*;

public class AnimalSerializer {

    public static void animalSerializer(Animal animal) {
        try(FileOutputStream fos = new FileOutputStream("animal.ser");
        ObjectOutputStream oos = new ObjectOutputStream(fos)) {
            oos.writeObject(animal);
            oos.flush();
        } catch (FileNotFoundException e) {
            System.out.println(e.getMessage());
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }

    public static void animalDeserializer(Animal animal) {
        try(FileInputStream fis = new FileInputStream("animal.ser");
        ObjectInputStream ois = new ObjectInputStream(fis)){

        } catch (FileNotFoundException e) {
            System.out.println(e.getMessage());
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
}
