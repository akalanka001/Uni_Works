public class Demo {
    public static void main(String[] args) {

        Animal cat = new Cat(100.0,"Red");
        AnimalSerializer.serializeAnimal(cat);
        AnimalSerializer.deserializeAnimal(cat);

    }
}
