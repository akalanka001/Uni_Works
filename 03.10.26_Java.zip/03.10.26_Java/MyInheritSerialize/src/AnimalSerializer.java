import java.io.*;

public class AnimalSerializer {


    public static void serializeAnimal(Animal animal) {

        try(FileOutputStream fos = new FileOutputStream("animal.ser");
            ObjectOutputStream oos = new ObjectOutputStream(fos)) {
            oos.writeObject(animal);
            oos.flush();
        } catch (FileNotFoundException e) {
            System.out.println("File not found");
        } catch (IOException e) {
            System.out.println("I/O exception");
        }

    }
    public static void deserializeAnimal(Animal animal) {
        try(FileInputStream fis = new FileInputStream("animal.ser");
            ObjectInputStream ois = new ObjectInputStream(fis)){

            Animal cat = (Animal)ois.readObject();
            System.out.println(cat);

        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
}