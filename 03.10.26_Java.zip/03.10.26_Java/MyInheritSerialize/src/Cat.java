public class Cat extends Animal {

    private String color;

    public Cat(double weight, String color) {
        super(weight);
        this.color = color;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    @Override
    public String toString() {
        return "Cat{" +
                " color = " + color + ", " +
                " weight = " + getWeight() +
                '}';
    }
}
