<html>
<head>
	<title>Calculator</title>
	<style>
		* {
			font-family: Arial;
		}
		.container {
			background-color: #F5F5DC;
			width: 40%;
			margin: 30px auto;
			padding: 20px;
			border: solid black 1px;
			border-radius: 6px;
		}
	</style>
</head>
<body>
	<div class="container">
		<form method="GET" action="">
			Number 1 : 
			<input type="number" name="n1" placeholder="0" required><br><br>
			Number 2 : 
			<input type="number" name="n2" placeholder="0" required><br><br>
			<input type="submit" name="add" value="Add(+)">&nbsp;&nbsp;&nbsp;
			<input type="submit" name="sub" value="Subtract(-)"><br><br>
			<input type="submit" name="mul" value="Multiply(x)">&nbsp;
			<input type="submit" name="div" value="Divide(/)">
		</form>

		<?php
			if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['n1']) && isset($_GET['n2'])) {
				$n1 = $_GET['n1'];
				$n2 = $_GET['n2'];

				function addition($n1, $n2) {
					return $n1 + $n2;
				}

				function subtract($n1, $n2) {
					return $n1 - $n2;
				}

				function multiply($n1, $n2) {
					return $n1 * $n2;
				}

				function divide($n1, $n2) {
					if ($n2 == 0) {
						return "Cannot divide by Zero.";
					}
					return $n1 / $n2;
				}

				if (isset($_GET["add"])) {
					$result = addition($n1, $n2);
					echo "<p>Result is: {$result}</p>";
				} else if (isset($_GET["sub"])) {
					$result = subtract($n1, $n2);
					echo "<p>Result is: {$result}</p>";
				} else if (isset($_GET["mul"])) {
					$result = multiply($n1, $n2);
					echo "<p>Result is: {$result}</p>";
				} else if (isset($_GET["div"])) {
					$result = divide($n1, $n2);
					echo "<p>Result is: {$result}</p>";
				}
			}
		?>
	</div>
</body>
</html>
