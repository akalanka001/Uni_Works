<?php
	$n = 5;
	function factorial($n){
		$fac = 1;
		if($n < 0){
			return "Factorial can't calculate for negative numbers";
		}
		for($i=1;$i<=$n;$i++){
			$fac *= $i;
		}
		return $fac;
	}
	$result = factorial($n);
	echo "Factorial of {$n} is {$result}<br>";
?>