<html>
	<head>
		<title>Formal Letter</title>
		<style>
			body{
				font-family: "Times New Roman", Times, serif;
				margin-top:40px;
				}
			.container{
				width:60%;
				margin-left:20%;
				background-color:yellow;
				padding:10px;
			}
			.registrar{
				text-align:right;
			}
			.title{
				text-align:center;
			}
		</style>
	</head>
	<body>
		<div class="container">
			<div class="registrar">
				<?php
					$regName = "Ms.A.D.Gunasekara";
					$recName = "Dear Ms.P.T.Kushani Perera";
				?>
				<p><?php echo "{$regName}"?><br>Registrar<br>Faculty of Technology<br>University of Ruhuna<br>Matara</p>
			</div>
			<div class="title">
				<h2><u>Student Enrollment</u></h2>
			</div>
			<div class="recName">
				<p>Dear <?php echo "{$recName}" ?><br>
			</div>
			<div class="body">
				<p>We are happy to inform that you are selected for the <b>Bachelor of ICT</b> degree program</p>
				<p>Thank you</p>
			</div>
			<div class="registrar">
				<p><?php echo "{$regName}" ?><br>Registrar<br>Faculty of Technology<br>University of Ruhuna<br>Matara</p>
			</div>
		</div>
	</body>
</html>