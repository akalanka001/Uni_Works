<?php
	$myArray = array();
	for($i=0;$i<5;$i++){
		$random=rand(1,500);
		echo"{$random}<br>";
		$myArray[$i] = $random;
	}
	for($i=0;$i<5;$i++){
		
	}
?>