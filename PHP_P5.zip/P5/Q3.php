<?php
	$x = 2;
	$y = 5;
	function findPower($x,$y){
		return pow($x,$y);
	}
	$result = findPower($x,$y);
	echo "Result of {$x}^{$y} is : {$result}<br>";
?>