<?php
	$name = 'localhost';
	$user = 'root';
	$password = '';
	$database = 'ICT_Dept_db';
	//connection
	$conn = mysqli_connect($name,$user,$password);
	if(!$conn){
		die("Can't connect . ".mysqli_error($conn));
	}
	echo "connected successfully<br>";
	
	//database creation
	$sql = "create database if not exists ICT_Dept_db";
	if(!mysqli_query($conn,$sql)){
		die("Can't create database . ".mysqli_error($conn));
	}
	echo "database created successfully<br>";
	
	$db_selected = mysqli_select_db($conn,$database);
	if(!$conn){
		die("Can't connect to database . ".mysqli_error($conn));
	}
	echo "database connected successfully<br>";
	
?>