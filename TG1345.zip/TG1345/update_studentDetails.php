<html>
	<body>
		<form action='update_studentDetails.php' method='post'>
			<table>
				<tr>
					<td>Index Number:</td>
					<td><input type='text' name='index'></td>
				</tr>
				<tr>
					<td>Email:</td>
					<td><input type='text' name='email'></td>
				</tr>
				<tr>
					<td><input type='submit' name='submit' value='Update'></td>
					<td><input type='reset' name='reset' value='Clear'></td>
				</tr>
			</table>
		</form>
	</body>
</html>
<?php
	require_once('connection.php');
	if(($_SERVER['REQUEST_METHOD'] == "POST") && (isset($_POST['submit']))){
		$index = $_POST['index'];
		$email = $_POST['email'];
		
		if((!empty($index)) || (!empty($email))){
			
			$sql = "select Index_Number from Student_Info";
			$result = mysqli_query($conn,$sql);
			$index_found = 0;
			//find index is exists
			while($row = mysqli_fetch_assoc($result)){
				if(($row['Index_Number']) == $index){
					$index_found = 1;
					break;
				}else{
					$index_found = 0;
				}
			}
			if($index_found == 1){
				$updateSql = "update Student_Info set Email = '$email' where Index_Number = '$index' ";
				if(!mysqli_query($conn,$updateSql)){
					die("Can't update email:".mysqli_error($conn));
				}
				echo "Record was updated successfully<br>";
			}else{
				echo "Please enter valid index number<br>";
			}
			
		}else{
			echo "Please fill all the fields<br>";
		}
	}
?>