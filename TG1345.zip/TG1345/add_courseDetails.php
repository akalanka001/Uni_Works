<?php
	require_once('connection.php');
	$sql = "select * from Course_Info";
	$result = mysqli_query($conn,$sql);
	
	echo "<table border='1'>";
	echo "<tr><th>Course_Id</th><th>Course_Name</th><th>Department_offered</th></tr>";
	while($row = mysqli_fetch_assoc($result)){
		echo "<tr><td>".$row['Course_Id']."</td>
				<td>".$row['Course_Name']."</td>
				<td>".$row['Department_offered']."</td>
			</tr>";
	}
	echo "</table><br><br>";
	
	//get user data
	if(($_SERVER['REQUEST_METHOD'] == "POST") && (isset($_POST['submit']))){
		
		$id = $_POST['id'];
		$name = $_POST['name'];
		$department = $_POST['Department_offered'];
		
		if((!empty($id)) || (!empty($name)) || (!empty($department))){
			
			$sql = "insert ignore into Course_Info values ('$id','$name','$department')";
			
			if(!mysqli_query($conn,$sql)){
		die("Can't insert data to table Course_info".mysqli_error($conn));
	}
	echo "Course_info inserted successfully<br>";
			
		}else{
			echo "please fill all the fields<br>";
		}
	}
	

?>
<html>
	<body>
		<form action="add_courseDetails.php" method="post">
			<table>
				<tr>
					<td>Course Id:</td>
					<td><input type='text' name='id'>
				</tr>
				<tr>
					<td>Course Name:</td>
					<td><input type='text' name='name'></td>
				</tr>
				<tr>
					<td>Department_offered:</td>
					<td>
						<select name='Department_offered'>
							<option value='ICT'>ICT</option>
							<option value='MDS'>MDS</option>
						</select>
					</td>
				</tr>
				<tr>
					<td><input type='submit' name='submit' value='Add Course'></td>
					<td><input type='reset' name='reset' value='Clear Values'></td>
				</tr>
			</table>
		</form>
	</body>
</html>