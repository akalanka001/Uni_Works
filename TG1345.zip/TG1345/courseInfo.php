<?php
	require_once('connection.php');
	
	$sql = "create table if not exists Course_Info( 
			Course_Id char(7) primary key,
			Course_Name varchar(10),
			Department_offered varchar(10)
			)";
			
	if(!mysqli_query($conn,$sql)){
		die("Can't create table Course_Info".mysqli_error($conn));
	}
	echo "Course_Info table create successfully<br>";
	
	$sql = "insert ignore into Course_Info values
			('ICT1233','PHP','ICT'),
			('ICT1212','Database','ICT'),
			('ICT1223','English','MDS')
			";
			
	if(!mysqli_query($conn,$sql)){
		die("Can't insert data to table Course_info".mysqli_error($conn));
	}
	echo "Course_info inserted successfully<br>";
	
	
?>