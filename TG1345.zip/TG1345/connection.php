<?php
	$name = 'localhost';
	$user = 'root';
	$password = '';
	$database = 'ICT_Dept_db';
	//connection
	$conn = mysqli_connect($name,$user,$password,$database);
	if(!$conn){
		die("Can't connect . ".mysqli_error($conn));
	}
	echo "connected successfully<br>";
?>