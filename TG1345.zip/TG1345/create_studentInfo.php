<?php
	require_once('connection.php');
	//create table Student_Info
	$sql = "create table if not exists Student_Info (
			Index_Number char(11) primary key,
			Student_Name varchar(20),
			Age int,
			Email varchar(50)
		  )";
		  
	if(!mysqli_query($conn,$sql)){
		die("Can't create table student_info".mysqli_error($conn));
	}
	echo "Student info table create successfully<br>";
	//insert into Student_Info
	$sql = "insert ignore into Student_Info values
			('TG/2021/465','Kalana',22,'kalana@gmail.com'),
			('TG/2021/520','Sanduni',21,'sanduni@gmail.com'),
			('TG/2021/678','Sajani',22,'sajani@gmail.com')
			";
	if(!mysqli_query($conn,$sql)){
		die("Can't insert data to table student_info".mysqli_error($conn));
	}
	echo "Student info inserted successfully<br>";
?>