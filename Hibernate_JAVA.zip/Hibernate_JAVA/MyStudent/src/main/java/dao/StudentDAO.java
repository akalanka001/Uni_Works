package dao;

import entity.Marks;
import entity.Student;
import org.hibernate.Session;
import org.hibernate.Transaction;
import util.HibernateUtil;

public class StudentDAO {

    //CREATE
    public void saveStudent(Student student) {
        Session session = HibernateUtil.getSessionFactory().openSession();

        Transaction tx = session.beginTransaction();
//        session.save(student);
        session.persist(student);
        tx.commit();
    }

    //READ
    public Student readStudent(int regNo) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();

        Student student = session.get(Student.class, regNo);

        if (student != null) {
            System.out.println("Student Name: " + student.getName());
            System.out.println("Email: " + student.getEmail());

            for (Marks m : student.getMarks()) {
                System.out.println("Course: " + m.getCourseId() +
                        ", Marks: " + m.getMarks());
            }
        } else {
            System.out.println("Student not found");
        }

        tx.commit();
        session.close();

        return student;
    }
    //UPDATE
    public void updateStudent(int regNo) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();

        Student student = session.get(Student.class, regNo);

        if (student != null) {
            // Update student details
            student.setName("Updated Name");
            student.setEmail("updated@email.com");

            // Update marks
            for (Marks m : student.getMarks()) {
                if (m.getCourseId().equals("CS101")) {
                    m.setMarks(95.0);
                }
            }

            // Add new mark
            Marks newMark = new Marks();
            newMark.setCourseId("CS202");
            newMark.setMarks(88.0);
            newMark.setStudent(student);

            student.getMarks().add(newMark);

            session.update(student);
        }

        tx.commit();
        session.close();
    }

    //DELETE
    public void deleteStudent(int regNo) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();

        Student student = session.get(Student.class, regNo);

        if (student != null) {
            session.delete(student);
            System.out.println("Student deleted successfully");
        } else {
            System.out.println("Student not found");
        }

        tx.commit();
        session.close();
    }
}
