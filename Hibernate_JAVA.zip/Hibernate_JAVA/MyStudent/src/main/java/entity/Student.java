package entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "student")
public class Student {

    @Id
    private int regNo;

    @Temporal(TemporalType.DATE)
    private Date dob;

    private String name;
    private String email;
    @OneToMany(mappedBy = "student",cascade = CascadeType.ALL,orphanRemoval = true)
    private List<Marks> marks = new ArrayList<Marks>();




    public void addMarks(Marks mark) {
        marks.add(mark);
        mark.setStudent(this);
    }


}
