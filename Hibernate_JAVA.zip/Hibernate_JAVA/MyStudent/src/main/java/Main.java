import dao.StudentDAO;
import entity.Marks;
import entity.Student;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Main {
    public static void main(String[] args) throws Exception {

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date dob = sdf.parse("2002-01-15");

        Student s1 = new Student();
        s1.setDob(dob);
        s1.setName("Aklanka");
        s1.setEmail("akalanka@gmail.com");

        Marks m1 = new Marks();
        m1.setCourseId("CS101");
        m1.setMarks(100);

        s1.addMarks(m1);

        StudentDAO dao = new StudentDAO();
        dao.saveStudent(s1);
    }
}