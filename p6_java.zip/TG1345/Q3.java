import java.util.Scanner;
public class Q3
{
	static double length;
	static double height;
	static double radius;
	static double answer;
	
	static double areaOfSquare(double length)
	{
		return (length * length);
	}
	static double areaOfCircle(double radius)
	{
		return (Math.PI * Math.pow(radius,2)); 	
	}
	static double areaOfRectangle(double length, double height)
	{
		return (length * height);
	}
	static double areaOfCylinder(double radius, double height)
	{
		return (2 * Math.PI * radius * height);
	}

	public static void main(String[] args)	
	{
		Scanner input = new Scanner(System.in);
		int number;
		do{
			System.out.println("\n----------------\n1.Square\n2.Circle\n3.Rectangle\n4.Cylinder\n0.Exit\n----------------\n\nEnter number : ");
			number = input.nextInt();
			
			switch(number){
				case 0 : break;
				case 1 : 
					System.out.println("Enter length : ");
					length = input.nextDouble();
					answer = areaOfSquare(length);
					break;
				case 2 : 
					System.out.println("Enter radius : ");
					radius = input.nextDouble();
					answer = areaOfCircle(radius);
					break;
				case 3 : 
					System.out.println("Enter length of side 1 : ");
					length = input.nextDouble();
					System.out.println("Enter length of side 2 : ");
					height = input.nextDouble();
					answer = areaOfRectangle(length,height);
					break;
				case 4 : 
					System.out.println("Enter radius : ");
					radius = input.nextDouble();
					System.out.println("Enter height : ");
					height = input.nextDouble();
					answer = areaOfCylinder(radius,height);
					break;
				default : System.out.println("Enter valid option number  !!!");
					
			}
			System.out.println("\n----------------\nAnswer is : " + answer + "\n----------------");
		}while(number != 0);

	}
}