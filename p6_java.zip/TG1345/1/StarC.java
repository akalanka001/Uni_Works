class StarC
{
	static int n = 4, i,j,k;
	public static void main(String[] args)
	{
		for(i=1; i<=n; i++){
			for(j=i; j<=n; j++){
				System.out.print(" ");
				
			}
			for(j=1; j<=i; j++){
				System.out.print("* ");
				
			}
		
			System.out.println();
		}
		for(i=1; i<=(n/2); i++){
			System.out.print("   ");
			for(j=1; j<=(n/2); j++){
				System.out.print("* ");
				
			}
			System.out.println();
				
		}
		
	}
}