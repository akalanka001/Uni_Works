class StarD
{
	static int n = 5, i,j;
	public static void main(String[] args)
	{
		for(i=1; i<=n; i++){
			for(j=i; j<=n; j++){
				System.out.print("  ");
				
			}
			for(j=1; j<=i; j++){
				System.out.print("* ");
				
			}
		
			System.out.println();
		}
		
	}
}