class StarA
{
	static int n = 4, i,j;
	public static void main(String[] args)
	{
		for(i=1; i<=n; i++){
			for(j=1; j<=i; j++){
				System.out.print("* ");
			}
			System.out.println();
		}
	}
}