import java.util.Scanner;
public class Q4
{
	public static void sorter(int a, int b, int c)
	{
		int max,temp;
		if(a <= b){
			max = b;
			b = c ;
			c = max;
			if(b <= a){
				temp = a;
				a = b;
				b = temp;
			}
		}	

		else if(a <= c){
			if(b <= a){
				temp = a;
				a = b;
				b = temp;
			}
			
		}
		System.out.println("A : " + a + " B : " + b + " C : " + c);

	}
	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);
		System.out.println("Enter A : ");
		int a = input.nextInt();
		System.out.println("Enter B : ");
		int b = input.nextInt();
		System.out.println("Enter C : ");
		int c = input.nextInt();

		sorter(a,b,c);
		
	}
}