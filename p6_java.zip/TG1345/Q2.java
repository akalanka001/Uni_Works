import java.util.Scanner;
class Q2
{
	static int i,j,number;
	public static void main(String[] args)
	{	
		Scanner input = new Scanner(System.in);
		System.out.println("Enter number : ");
		number = input.nextInt();
		starPattern(number);
		 
		
		
	}
	static void starPattern(int n)
	{
		for(i=1; i<=n; i++){
			for(j=i; j<=n; j++){
				System.out.print(" ");
				
			}
			for(j=1; j<=i; j++){
				System.out.print("* ");
				
			}
		
			System.out.println();
		}
		
	}
}