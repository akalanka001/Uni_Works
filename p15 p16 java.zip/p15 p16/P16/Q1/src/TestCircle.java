public class TestCircle {
    public static void main(String[] args) {
        Circle circle = new Circle(7.0);
        System.out.printf("Circle perimeter : %.2f\nCircle Area : %.2f\n\n\n",circle.getPerimeter(), circle.getArea());
        circle.radius = 14.0;
        System.out.printf("Circle Radius : %.2f\nCircle perimeter : %.2f\nCircle Area : %.2f\n\n\n",circle.radius, circle.getPerimeter(), circle.getArea());

        ResizableCircle rCircle = new ResizableCircle(7.0);
        System.out.printf("Circle perimeter : %.2f\nCircle Area : %.2f\n\n\n",rCircle.getPerimeter(), rCircle.getArea());

        rCircle.resize(100);
        System.out.printf("Circle Radius : %.2f\nCircle perimeter : %.2f\nCircle Area : %.2f\n\n\n",rCircle.radius, rCircle.getPerimeter(), rCircle.getArea());

        rCircle.radius = 7.0;
        rCircle.resize(-100);
        System.out.printf("Circle Radius : %.2f\nCircle perimeter : %.2f\nCircle Area : %.2f\n\n\n",rCircle.radius, rCircle.getPerimeter(), rCircle.getArea());


    }
}
