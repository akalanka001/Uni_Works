import java.util.Scanner;

public class Circle implements GeometricObject{
    protected double radius = 1.0;

    public Circle() {
    }

    public Circle(double radius){
        this.radius = radius;
    }
    public double getPerimeter(){
        return 2 * Math.PI * radius;
    }
    public double getArea(){
        return Math.PI * radius * radius;
    }

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.print("Enter the radius of the circle: ");
        double radius = scan.nextDouble();
        if(radius < 0) {
            System.out.println("Negative values are not allowed.please re-enter positive number : ");
            return;
        }
        Circle c1 = new Circle(radius);
        System.out.printf("Perimeter of the circle is: %.2f\n", c1.getPerimeter());
        System.out.printf("Area of the circle is: %.2f\n", c1.getArea());
    }
}
