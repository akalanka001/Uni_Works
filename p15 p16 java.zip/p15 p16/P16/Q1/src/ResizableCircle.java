import java.util.Scanner;

public class ResizableCircle extends Circle implements Resizable{

    public ResizableCircle(double radius) {
        super(radius);
    }

    @Override
    public void resize(int percent) {
        super.radius = radius + (radius * (((double) percent ) / 100.0));
    }

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        System.out.print("Enter the radius of the circle: ");
        double radius = scan.nextDouble();

        ResizableCircle circle = new ResizableCircle(radius);

        do{
            System.out.print("Enter the percent value (-100 to 100): ");
            int percent = scan.nextInt();

            if (percent < -100 || percent > 100) {
                System.out.println("Invalid percent value, please re-enter the value between -100 to 100");
            }else {
                circle.resize(percent);
                System.out.printf("Resized circle Perimeter is: %.2f\n", circle.getPerimeter());
                System.out.printf("Resized circle area is: %.2f\n", circle.getArea());
                return;
            }
        }while(true);

    }
}
