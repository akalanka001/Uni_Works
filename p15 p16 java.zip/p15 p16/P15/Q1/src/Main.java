import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Main extends JFrame {
    private JPanel content;
    private JTextField Number1;
    private JTextField Number2;
    private JLabel answer;
    private JButton divideButton;


    public Main() {
        setContentPane(content);
        setTitle("Calculator");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(300, 200);
        setLocationRelativeTo(null);
        setVisible(true);

        divideButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    double n1 = Double.parseDouble(Number1.getText());
                    double n2 = Double.parseDouble(Number2.getText());
                    if(n2 == 0){
                        JOptionPane.showMessageDialog(Main.this, "You can't enter 0 for second number");
                    }else{
                        double result = n1 / n2;
                        String strResult = String.format("%.2f",result);
                        answer.setText(strResult);

                    }
                }catch (NumberFormatException ex){
                    JOptionPane.showMessageDialog(Main.this, "Please enter numbers only");
                }

            }
        });
    }

    public static void main(String[] args) {
        new Main();
    }
}
