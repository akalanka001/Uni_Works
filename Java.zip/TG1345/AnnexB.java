import java.util.Scanner;
public class AnnexB
{
	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);
		int number;
		do{
			System.out.println("Please enter the number of the shape \n1.Sphere\n2.Cone\n0.Exit\n\nEnter your Answer : ");
			number = input.nextInt();
			
			if(number == 1)
			{
				System.out.println("You have Selected the Sphere\n");
				System.out.println("Enter radius : ");
				double radius = input.nextDouble();
				double SphereVolume = getSphereVolume(radius);
				System.out.println("Volume of the Sphere is : " + SphereVolume);
			}
			if(number  == 2)
			{
				System.out.println("You have Selected the Cone\n");
				System.out.println("Enter radius : ");
				double radius = input.nextDouble();

				System.out.println("Enter height");
				double height = input.nextDouble();

				double ConeVolume = getConeVolume(radius,height);
				System.out.println("Volume of the Cone is : " + ConeVolume);
			}
			if(number == 3)
			{
				System.out.println("You have Selected the MyShape\n");
				System.out.println("Enter radius : ");
				double radius = input.nextDouble();

				System.out.println("Enter height");
				double height = input.nextDouble();
			}
			
					

		}while(number  != 0);

		

		
		 
	}


	public static double getSphereVolume(double radius)
	{
		double SphereVolume = (4.0/3.0) * Math.PI * Math.pow(radius,3);
		return SphereVolume;
		
	}

	public static double getConeVolume(double radius, double height)
	{
		double ConeVolume = (1.0/3.0) * Math.PI * Math.pow(radius,2) * height;
		return ConeVolume;
	}

	public static getMyShapeVolume(double radius, double height)
	{
		
	}
	
}