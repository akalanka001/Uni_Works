import java.util.ArrayList;

public class NoGenericExample {
    public static void main(String[] args) {
        ArrayList<String> list = new ArrayList<>();
        list.add("Java");
        list.add("123");

        String text = list.get(0);
//        String number = (String) list.get(1);
        System.out.println(list);
    }
}
