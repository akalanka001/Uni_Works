import java.util.HashSet;

public class SetExample {
    public static void main(String[] args) {
        HashSet<String> fruits = new HashSet<>();

        fruits.add("Apple");
        fruits.add("Banana");
        fruits.add("Apple"); //Duplicates Ignored

        for(String fruit : fruits){
            System.out.println(fruit);
        }

    }
}
