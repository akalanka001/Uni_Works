import java.util.ArrayList;

public class ListExample {
    public static void main(String[] args) {
        ArrayList<String> names = new ArrayList<>();

        names.add("Nimal");
        names.add("Bob");
        names.add("Nimal");

        System.out.println("First name : " + names.get(0));

        for(String name : names){
            System.out.println(name);
        }
    }
}
