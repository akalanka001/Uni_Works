import java.util.HashMap;

public class MapExample {
    public static void main(String[] args) {
        HashMap<String,Integer> marks = new HashMap<>();

        marks.put("Tom", 50);
        marks.put("Jerry",80);
        marks.put("Tom", 95); // Overwrites previous value

        for(String name : marks.keySet()){
            System.out.println(name + " Scored " + marks.get(name));
        }
    }
}
