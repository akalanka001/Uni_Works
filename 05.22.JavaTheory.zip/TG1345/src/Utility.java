import java.lang.reflect.Array;

public class Utility {
    public static <T>void printArray(T[] array){
        for(T item : array){
            System.out.println(item);
        }
    }

    public static void main(String[] args) {

        String[] names = {"Amal","Kamal","Nihal"};
        Integer[] numbers = {1,2,3,4,5};
        Utility.printArray(names);
        Utility.printArray(numbers);
    }
}
